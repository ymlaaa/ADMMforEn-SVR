source("ADMMFunction.R")
#library(l1svr)
#library(lpSolve)
#library(lpSolveAPI)
n.test=500
##################################### Example 3
######## n=500 p=500
n.train=500
p=500
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(1)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}
#L1-SVR(ADMM)
lambda1=5
lambda2=0
epsilon=0.1
beta=1
eta=0.1
l1svradmm1=list()
l1svradmm1$rmse=rep(0,10)
l1svradmm1$mae=rep(0,10)
l1svradmm1$nonzeroerror=rep(0,10)
l1svradmm1$sparse=rep(0,10)
l1svradmm1$k=rep(0,10)
l1svradmm1$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  l1svradmm1$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  l1svradmm1$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  l1svradmm1$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  l1svradmm1$sparse[i]=sum(abs(result$w)<10^(-2))
  l1svradmm1$k[i]=result$k
  l1svradmm1$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=10
lambda2=0.01
epsilon=0.1
beta=1
eta=0.1
ensvr1=list()
ensvr1$rmse=rep(0,10)
ensvr1$mae=rep(0,10)
ensvr1$nonzeroerror=rep(0,10)
ensvr1$sparse=rep(0,10)
ensvr1$k=rep(0,10)
ensvr1$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr1$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr1$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr1$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr1$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr1$k[i]=result$k
  ensvr1$time[i]=(endt-begint)[3]
}

######## n=500 p=2000
n.train=500
p=2000
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(2)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}
#L1-SVR(ADMM)
lambda1=1
lambda2=0
epsilon=0.1
beta=1
eta=0.1
l1svradmm2=list()
l1svradmm2$rmse=rep(0,10)
l1svradmm2$mae=rep(0,10)
l1svradmm2$nonzeroerror=rep(0,10)
l1svradmm2$sparse=rep(0,10)
l1svradmm2$k=rep(0,10)
l1svradmm2$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  l1svradmm2$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  l1svradmm2$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  l1svradmm2$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  l1svradmm2$sparse[i]=sum(abs(result$w)<10^(-2))
  l1svradmm2$k[i]=result$k
  l1svradmm2$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr2=list()
ensvr2$rmse=rep(0,10)
ensvr2$mae=rep(0,10)
ensvr2$nonzeroerror=rep(0,10)
ensvr2$sparse=rep(0,10)
ensvr2$k=rep(0,10)
ensvr2$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr2$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr2$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr2$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr2$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr2$k[i]=result$k
  ensvr2$time[i]=(endt-begint)[3]
}

######## n=2000 p=500
n.train=2000
p=500
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(3)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}
#L1-SVR(ADMM)
lambda1=0.1
lambda2=0
epsilon=0.1
beta=0.1
eta=0.9
l1svradmm3=list()
l1svradmm3$rmse=rep(0,10)
l1svradmm3$mae=rep(0,10)
l1svradmm3$nonzeroerror=rep(0,10)
l1svradmm3$sparse=rep(0,10)
l1svradmm3$k=rep(0,10)
l1svradmm3$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  l1svradmm3$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  l1svradmm3$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  l1svradmm3$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  l1svradmm3$sparse[i]=sum(abs(result$w)<10^(-2))
  l1svradmm3$k[i]=result$k
  l1svradmm3$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.1
lambda2=0.001
epsilon=0.1
beta=0.1
eta=0.9
ensvr3=list()
ensvr3$rmse=rep(0,10)
ensvr3$mae=rep(0,10)
ensvr3$nonzeroerror=rep(0,10)
ensvr3$sparse=rep(0,10)
ensvr3$k=rep(0,10)
ensvr3$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr3$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr3$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr3$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr3$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr3$k[i]=result$k
  ensvr3$time[i]=(endt-begint)[3]
}

######## n=2000 p=2000
n.train=2000
p=2000
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(4)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}
#L1-SVR(ADMM)
lambda1=5
lambda2=0
epsilon=0.1
beta=1
eta=0.1
l1svradmm4=list()
l1svradmm4$rmse=rep(0,10)
l1svradmm4$mae=rep(0,10)
l1svradmm4$nonzeroerror=rep(0,10)
l1svradmm4$sparse=rep(0,10)
l1svradmm4$k=rep(0,10)
l1svradmm4$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  l1svradmm4$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  l1svradmm4$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  l1svradmm4$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  l1svradmm4$sparse[i]=sum(abs(result$w)<10^(-2))
  l1svradmm4$k[i]=result$k
  l1svradmm4$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=10
lambda2=0.01
epsilon=0.1
beta=1
eta=0.1
ensvr4=list()
ensvr4$rmse=rep(0,10)
ensvr4$mae=rep(0,10)
ensvr4$nonzeroerror=rep(0,10)
ensvr4$sparse=rep(0,10)
ensvr4$k=rep(0,10)
ensvr4$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr4$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr4$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr4$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr4$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr4$k[i]=result$k
  ensvr4$time[i]=(endt-begint)[3]
}




##################################### Example 4
######## n=500 p=500
n.train=500
p=500
cc=sqrt(3)*((t(c(4,3,2,-2,-2,-2,rep(0,p-6)))%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))[1,1])
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(5)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))+(1/cc)*(x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))^2*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)
  y.test.list[[i]]=x.test.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))
}
#L1-SVR(ADMM)
lambda1=10
lambda2=0
epsilon=0.1
beta=1
eta=0.1
l1svradmm5=list()
l1svradmm5$rmse=rep(0,10)
l1svradmm5$mae=rep(0,10)
l1svradmm5$nonzeroerror=rep(0,10)
l1svradmm5$sparse=rep(0,10)
l1svradmm5$k=rep(0,10)
l1svradmm5$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  l1svradmm5$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  l1svradmm5$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  l1svradmm5$nonzeroerror[i]=mean(abs(result$w[c(1:6)]-c(4,3,2,-2,-2,-2)))
  l1svradmm5$sparse[i]=sum(abs(result$w)<10^(-2))
  l1svradmm5$k[i]=result$k
  l1svradmm5$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=10
lambda2=0.01
epsilon=0.1
beta=0.1
eta=0.1
ensvr5=list()
ensvr5$rmse=rep(0,10)
ensvr5$mae=rep(0,10)
ensvr5$nonzeroerror=rep(0,10)
ensvr5$sparse=rep(0,10)
ensvr5$k=rep(0,10)
ensvr5$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr5$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr5$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr5$nonzeroerror[i]=mean(abs(result$w[c(1:6)]-c(4,3,2,-2,-2,-2)))
  ensvr5$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr5$k[i]=result$k
  ensvr5$time[i]=(endt-begint)[3]
}

######## n=500 p=2000
n.train=500
p=2000
cc=sqrt(3)*((t(c(4,3,2,-2,-2,-2,rep(0,p-6)))%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))[1,1])
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(6)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))+(1/cc)*(x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))^2*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)
  y.test.list[[i]]=x.test.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))
}
#L1-SVR(ADMM)
lambda1=1
lambda2=0
epsilon=0.1
beta=1
eta=0.1
l1svradmm6=list()
l1svradmm6$rmse=rep(0,10)
l1svradmm6$mae=rep(0,10)
l1svradmm6$nonzeroerror=rep(0,10)
l1svradmm6$sparse=rep(0,10)
l1svradmm6$k=rep(0,10)
l1svradmm6$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  l1svradmm6$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  l1svradmm6$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  l1svradmm6$nonzeroerror[i]=mean(abs(result$w[c(1:6)]-c(4,3,2,-2,-2,-2)))
  l1svradmm6$sparse[i]=sum(abs(result$w)<10^(-2))
  l1svradmm6$k[i]=result$k
  l1svradmm6$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=10
lambda2=0.01
epsilon=0.1
beta=1
eta=0.9
ensvr6=list()
ensvr6$rmse=rep(0,10)
ensvr6$mae=rep(0,10)
ensvr6$nonzeroerror=rep(0,10)
ensvr6$sparse=rep(0,10)
ensvr6$k=rep(0,10)
ensvr6$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr6$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr6$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr6$nonzeroerror[i]=mean(abs(result$w[c(1:6)]-c(4,3,2,-2,-2,-2)))
  ensvr6$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr6$k[i]=result$k
  ensvr6$time[i]=(endt-begint)[3]
}

######## n=2000 p=500
n.train=2000
p=500
cc=sqrt(3)*((t(c(4,3,2,-2,-2,-2,rep(0,p-6)))%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))[1,1])
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(7)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))+(1/cc)*(x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))^2*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)
  y.test.list[[i]]=x.test.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))
}
#L1-SVR(ADMM)
lambda1=1
lambda2=0
epsilon=0.1
beta=0.1
eta=0.9
l1svradmm7=list()
l1svradmm7$rmse=rep(0,10)
l1svradmm7$mae=rep(0,10)
l1svradmm7$nonzeroerror=rep(0,10)
l1svradmm7$sparse=rep(0,10)
l1svradmm7$k=rep(0,10)
l1svradmm7$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  l1svradmm7$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  l1svradmm7$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  l1svradmm7$nonzeroerror[i]=mean(abs(result$w[c(1:6)]-c(4,3,2,-2,-2,-2)))
  l1svradmm7$sparse[i]=sum(abs(result$w)<10^(-2))
  l1svradmm7$k[i]=result$k
  l1svradmm7$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=1
lambda2=0.01
epsilon=0.1
beta=0.1
eta=0.9
ensvr7=list()
ensvr7$rmse=rep(0,10)
ensvr7$mae=rep(0,10)
ensvr7$nonzeroerror=rep(0,10)
ensvr7$sparse=rep(0,10)
ensvr7$k=rep(0,10)
ensvr7$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr7$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr7$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr7$nonzeroerror[i]=mean(abs(result$w[c(1:6)]-c(4,3,2,-2,-2,-2)))
  ensvr7$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr7$k[i]=result$k
  ensvr7$time[i]=(endt-begint)[3]
}

######## n=2000 p=2000
n.train=2000
p=2000
cc=sqrt(3)*((t(c(4,3,2,-2,-2,-2,rep(0,p-6)))%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))[1,1])
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(8)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))+(1/cc)*(x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))^2*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)
  y.test.list[[i]]=x.test.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))
}
#L1-SVR(ADMM)
lambda1=10
lambda2=0
epsilon=0.1
beta=1
eta=0.1
l1svradmm8=list()
l1svradmm8$rmse=rep(0,10)
l1svradmm8$mae=rep(0,10)
l1svradmm8$nonzeroerror=rep(0,10)
l1svradmm8$sparse=rep(0,10)
l1svradmm8$k=rep(0,10)
l1svradmm8$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  l1svradmm8$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  l1svradmm8$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  l1svradmm8$nonzeroerror[i]=mean(abs(result$w[c(1:6)]-c(4,3,2,-2,-2,-2)))
  l1svradmm8$sparse[i]=sum(abs(result$w)<10^(-2))
  l1svradmm8$k[i]=result$k
  l1svradmm8$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=10
lambda2=0.01
epsilon=0.1
beta=0.1
eta=0.1
ensvr8=list()
ensvr8$rmse=rep(0,10)
ensvr8$mae=rep(0,10)
ensvr8$nonzeroerror=rep(0,10)
ensvr8$sparse=rep(0,10)
ensvr8$k=rep(0,10)
ensvr8$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr8$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr8$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr8$nonzeroerror[i]=mean(abs(result$w[c(1:6)]-c(4,3,2,-2,-2,-2)))
  ensvr8$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr8$k[i]=result$k
  ensvr8$time[i]=(endt-begint)[3]
}

save.image("ADMMvsLP.RData")

c(mean(l1svradmm1$rmse),mean(ensvr1$rmse))
c(mean(l1svradmm1$mae),mean(ensvr1$mae))
c(mean(l1svradmm1$nonzeroerror),mean(ensvr1$nonzeroerror))
c(mean(l1svradmm1$sparse),mean(ensvr1$sparse))
c(mean(l1svradmm1$time),mean(ensvr1$time))

c(mean(l1svradmm2$rmse),mean(ensvr2$rmse))
c(mean(l1svradmm2$mae),mean(ensvr2$mae))
c(mean(l1svradmm2$nonzeroerror),mean(ensvr2$nonzeroerror))
c(mean(l1svradmm2$sparse),mean(ensvr2$sparse))
c(mean(l1svradmm2$time),mean(ensvr2$time))

c(mean(l1svradmm3$rmse),mean(ensvr3$rmse))
c(mean(l1svradmm3$mae),mean(ensvr3$mae))
c(mean(l1svradmm3$nonzeroerror),mean(ensvr3$nonzeroerror))
c(mean(l1svradmm3$sparse),mean(ensvr3$sparse))
c(mean(l1svradmm3$time),mean(ensvr3$time))

c(mean(l1svradmm4$rmse),mean(ensvr4$rmse))
c(mean(l1svradmm4$mae),mean(ensvr4$mae))
c(mean(l1svradmm4$nonzeroerror),mean(ensvr4$nonzeroerror))
c(mean(l1svradmm4$sparse),mean(ensvr4$sparse))
c(mean(l1svradmm4$time),mean(ensvr4$time))

c(mean(l1svradmm5$rmse),mean(ensvr5$rmse))
c(mean(l1svradmm5$mae),mean(ensvr5$mae))
c(mean(l1svradmm5$nonzeroerror),mean(ensvr5$nonzeroerror))
c(mean(l1svradmm5$sparse),mean(ensvr5$sparse))
c(mean(l1svradmm5$time),mean(ensvr5$time))

c(mean(l1svradmm6$rmse),mean(ensvr6$rmse))
c(mean(l1svradmm6$mae),mean(ensvr6$mae))
c(mean(l1svradmm6$nonzeroerror),mean(ensvr6$nonzeroerror))
c(mean(l1svradmm6$sparse),mean(ensvr6$sparse))
c(mean(l1svradmm6$time),mean(ensvr6$time))

c(mean(l1svradmm7$rmse),mean(ensvr7$rmse))
c(mean(l1svradmm7$mae),mean(ensvr7$mae))
c(mean(l1svradmm7$nonzeroerror),mean(ensvr7$nonzeroerror))
c(mean(l1svradmm7$sparse),mean(ensvr7$sparse))
c(mean(l1svradmm7$time),mean(ensvr7$time))

c(mean(l1svradmm8$rmse),mean(ensvr8$rmse))
c(mean(l1svradmm8$mae),mean(ensvr8$mae))
c(mean(l1svradmm8$nonzeroerror),mean(ensvr8$nonzeroerror))
c(mean(l1svradmm8$sparse),mean(ensvr8$sparse))
c(mean(l1svradmm8$time),mean(ensvr8$time))
