source("ADMMFunction.R")
#library(svrpath)
#library(svmpath)
n.test=500
##################################### Example 1
########n=200
n.train=200
p=10
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(1)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(1:10)+5+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(1:10)+5
}
#SVR(ADMM)
lambda1=0
lambda2=0.01
epsilon=0.1
beta=0.01
eta=0.9
svradmm1=list()
svradmm1$rmse=rep(0,10)
svradmm1$mae=rep(0,10)
svradmm1$nonzeroerror=rep(0,10)
svradmm1$k=rep(0,10)
svradmm1$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm1$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm1$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm1$nonzeroerror[i]=mean(abs(result$w-c(1:10)))
  svradmm1$k[i]=result$k
  svradmm1$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr1=list()
ensvr1$rmse=rep(0,10)
ensvr1$mae=rep(0,10)
ensvr1$nonzeroerror=rep(0,10)
ensvr1$k=rep(0,10)
ensvr1$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr1$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr1$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr1$nonzeroerror[i]=mean(abs(result$w-c(1:10)))
  ensvr1$k[i]=result$k
  ensvr1$time[i]=(endt-begint)[3]
}

########n=500
n.train=500
p=10
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(2)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(1:10)+5+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(1:10)+5
}
#SVR(ADMM)
lambda1=0
lambda2=0.01
epsilon=0.1
beta=0.01
eta=0.9
svradmm2=list()
svradmm2$rmse=rep(0,10)
svradmm2$mae=rep(0,10)
svradmm2$nonzeroerror=rep(0,10)
svradmm2$k=rep(0,10)
svradmm2$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm2$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm2$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm2$nonzeroerror[i]=mean(abs(result$w-c(1:10)))
  svradmm2$k[i]=result$k
  svradmm2$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.01
epsilon=0.1
beta=0.01
eta=0.9
ensvr2=list()
ensvr2$rmse=rep(0,10)
ensvr2$mae=rep(0,10)
ensvr2$nonzeroerror=rep(0,10)
ensvr2$k=rep(0,10)
ensvr2$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr2$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr2$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr2$nonzeroerror[i]=mean(abs(result$w-c(1:10)))
  ensvr2$k[i]=result$k
  ensvr2$time[i]=(endt-begint)[3]
}

########n=1000
n.train=1000
p=10
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(3)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(1:10)+5+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(1:10)+5
}
#SVR(ADMM)
lambda1=0
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
svradmm3=list()
svradmm3$rmse=rep(0,10)
svradmm3$mae=rep(0,10)
svradmm3$nonzeroerror=rep(0,10)
svradmm3$k=rep(0,10)
svradmm3$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm3$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm3$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm3$nonzeroerror[i]=mean(abs(result$w-c(1:10)))
  svradmm3$k[i]=result$k
  svradmm3$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr3=list()
ensvr3$rmse=rep(0,10)
ensvr3$mae=rep(0,10)
ensvr3$nonzeroerror=rep(0,10)
ensvr3$k=rep(0,10)
ensvr3$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr3$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr3$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr3$nonzeroerror[i]=mean(abs(result$w-c(1:10)))
  ensvr3$k[i]=result$k
  ensvr3$time[i]=(endt-begint)[3]
}

########n=2000
n.train=2000
p=10
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(4)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(1:10)+5+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(1:10)+5
}
#SVR(ADMM)
lambda1=0
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
svradmm4=list()
svradmm4$rmse=rep(0,10)
svradmm4$mae=rep(0,10)
svradmm4$nonzeroerror=rep(0,10)
svradmm4$k=rep(0,10)
svradmm4$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm4$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm4$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm4$nonzeroerror[i]=mean(abs(result$w-c(1:10)))
  svradmm4$k[i]=result$k
  svradmm4$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr4=list()
ensvr4$rmse=rep(0,10)
ensvr4$mae=rep(0,10)
ensvr4$nonzeroerror=rep(0,10)
ensvr4$k=rep(0,10)
ensvr4$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr4$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr4$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr4$nonzeroerror[i]=mean(abs(result$w-c(1:10)))
  ensvr4$k[i]=result$k
  ensvr4$time[i]=(endt-begint)[3]
}



##################################### Example 2
########n=200
n.train=200
p=20
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(5)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))
}
#SVR(ADMM)
lambda1=0
lambda2=0.01
epsilon=0.1
beta=0.01
eta=0.9
svradmm5=list()
svradmm5$rmse=rep(0,10)
svradmm5$mae=rep(0,10)
svradmm5$nonzeroerror=rep(0,10)
svradmm5$k=rep(0,10)
svradmm5$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm5$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm5$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm5$nonzeroerror[i]=mean(abs(result$w-c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))))
  svradmm5$k[i]=result$k
  svradmm5$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.01
epsilon=0.1
beta=0.01
eta=0.9
ensvr5=list()
ensvr5$rmse=rep(0,10)
ensvr5$mae=rep(0,10)
ensvr5$nonzeroerror=rep(0,10)
ensvr5$k=rep(0,10)
ensvr5$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr5$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr5$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr5$nonzeroerror[i]=mean(abs(result$w-c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))))
  ensvr5$k[i]=result$k
  ensvr5$time[i]=(endt-begint)[3]
}

########n=500
n.train=500
p=20
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(6)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))
}
#SVR(ADMM)
lambda1=0
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
svradmm6=list()
svradmm6$rmse=rep(0,10)
svradmm6$mae=rep(0,10)
svradmm6$nonzeroerror=rep(0,10)
svradmm6$k=rep(0,10)
svradmm6$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm6$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm6$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm6$nonzeroerror[i]=mean(abs(result$w-c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))))
  svradmm6$k[i]=result$k
  svradmm6$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr6=list()
ensvr6$rmse=rep(0,10)
ensvr6$mae=rep(0,10)
ensvr6$nonzeroerror=rep(0,10)
ensvr6$k=rep(0,10)
ensvr6$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr6$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr6$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr6$nonzeroerror[i]=mean(abs(result$w-c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))))
  ensvr6$k[i]=result$k
  ensvr6$time[i]=(endt-begint)[3]
}

########n=1000
n.train=1000
p=20
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(7)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))
}
#SVR(ADMM)
lambda1=0
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
svradmm7=list()
svradmm7$rmse=rep(0,10)
svradmm7$mae=rep(0,10)
svradmm7$nonzeroerror=rep(0,10)
svradmm7$k=rep(0,10)
svradmm7$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm7$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm7$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm7$nonzeroerror[i]=mean(abs(result$w-c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))))
  svradmm7$k[i]=result$k
  svradmm7$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr7=list()
ensvr7$rmse=rep(0,10)
ensvr7$mae=rep(0,10)
ensvr7$nonzeroerror=rep(0,10)
ensvr7$k=rep(0,10)
ensvr7$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr7$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr7$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr7$nonzeroerror[i]=mean(abs(result$w-c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))))
  ensvr7$k[i]=result$k
  ensvr7$time[i]=(endt-begint)[3]
}

########n=2000
n.train=2000
p=20
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(8)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))
}
#SVR(ADMM)
lambda1=0
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
svradmm8=list()
svradmm8$rmse=rep(0,10)
svradmm8$mae=rep(0,10)
svradmm8$nonzeroerror=rep(0,10)
svradmm8$k=rep(0,10)
svradmm8$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm8$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm8$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm8$nonzeroerror[i]=mean(abs(result$w-c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))))
  svradmm8$k[i]=result$k
  svradmm8$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr8=list()
ensvr8$rmse=rep(0,10)
ensvr8$mae=rep(0,10)
ensvr8$nonzeroerror=rep(0,10)
ensvr8$k=rep(0,10)
ensvr8$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr8$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr8$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr8$nonzeroerror[i]=mean(abs(result$w-c(rep(3,5),rep(-1.5,5),rep(1,5),rep(2,5))))
  ensvr8$k[i]=result$k
  ensvr8$time[i]=(endt-begint)[3]
}


##################################### Example 5
########n=200
n.train=200
p=8
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(9)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(8,-7,6,-5,4,-3,2,-1)+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(8,-7,6,-5,4,-3,2,-1)
}
#SVR(ADMM)
lambda1=0
lambda2=0.01
epsilon=0.1
beta=0.01
eta=0.9
svradmm9=list()
svradmm9$rmse=rep(0,10)
svradmm9$mae=rep(0,10)
svradmm9$nonzeroerror=rep(0,10)
svradmm9$k=rep(0,10)
svradmm9$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm9$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm9$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm9$nonzeroerror[i]=mean(abs(result$w-c(8,-7,6,-5,4,-3,2,-1)))
  svradmm9$k[i]=result$k
  svradmm9$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr9=list()
ensvr9$rmse=rep(0,10)
ensvr9$mae=rep(0,10)
ensvr9$nonzeroerror=rep(0,10)
ensvr9$k=rep(0,10)
ensvr9$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr9$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr9$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr9$nonzeroerror[i]=mean(abs(result$w-c(8,-7,6,-5,4,-3,2,-1)))
  ensvr9$k[i]=result$k
  ensvr9$time[i]=(endt-begint)[3]
}

########n=500
n.train=500
p=8
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(10)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(8,-7,6,-5,4,-3,2,-1)+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(8,-7,6,-5,4,-3,2,-1)
}
#SVR(ADMM)
lambda1=0
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
svradmm10=list()
svradmm10$rmse=rep(0,10)
svradmm10$mae=rep(0,10)
svradmm10$nonzeroerror=rep(0,10)
svradmm10$k=rep(0,10)
svradmm10$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm10$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm10$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm10$nonzeroerror[i]=mean(abs(result$w-c(8,-7,6,-5,4,-3,2,-1)))
  svradmm10$k[i]=result$k
  svradmm10$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr10=list()
ensvr10$rmse=rep(0,10)
ensvr10$mae=rep(0,10)
ensvr10$nonzeroerror=rep(0,10)
ensvr10$k=rep(0,10)
ensvr10$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr10$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr10$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr10$nonzeroerror[i]=mean(abs(result$w-c(8,-7,6,-5,4,-3,2,-1)))
  ensvr10$k[i]=result$k
  ensvr10$time[i]=(endt-begint)[3]
}

########n=1000
n.train=1000
p=8
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(11)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(8,-7,6,-5,4,-3,2,-1)+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(8,-7,6,-5,4,-3,2,-1)
}
#SVR(ADMM)
lambda1=0
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
svradmm11=list()
svradmm11$rmse=rep(0,10)
svradmm11$mae=rep(0,10)
svradmm11$nonzeroerror=rep(0,10)
svradmm11$k=rep(0,10)
svradmm11$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm11$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm11$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm11$nonzeroerror[i]=mean(abs(result$w-c(8,-7,6,-5,4,-3,2,-1)))
  svradmm11$k[i]=result$k
  svradmm11$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr11=list()
ensvr11$rmse=rep(0,10)
ensvr11$mae=rep(0,10)
ensvr11$nonzeroerror=rep(0,10)
ensvr11$k=rep(0,10)
ensvr11$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr11$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr11$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr11$nonzeroerror[i]=mean(abs(result$w-c(8,-7,6,-5,4,-3,2,-1)))
  ensvr11$k[i]=result$k
  ensvr11$time[i]=(endt-begint)[3]
}

########n=2000
n.train=2000
p=8
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(12)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(8,-7,6,-5,4,-3,2,-1)+error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(8,-7,6,-5,4,-3,2,-1)
}
#SVR(ADMM)
lambda1=0
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
svradmm12=list()
svradmm12$rmse=rep(0,10)
svradmm12$mae=rep(0,10)
svradmm12$nonzeroerror=rep(0,10)
svradmm12$k=rep(0,10)
svradmm12$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  svradmm12$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  svradmm12$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  svradmm12$nonzeroerror[i]=mean(abs(result$w-c(8,-7,6,-5,4,-3,2,-1)))
  svradmm12$k[i]=result$k
  svradmm12$time[i]=(endt-begint)[3]
}
#En-SVR
lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=0.01
eta=0.9
ensvr12=list()
ensvr12$rmse=rep(0,10)
ensvr12$mae=rep(0,10)
ensvr12$nonzeroerror=rep(0,10)
ensvr12$k=rep(0,10)
ensvr12$time=rep(0,10)
for(i in 1:10){
  begint <- proc.time()
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  endt <- proc.time()
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr12$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr12$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr12$nonzeroerror[i]=mean(abs(result$w-c(8,-7,6,-5,4,-3,2,-1)))
  ensvr12$k[i]=result$k
  ensvr12$time[i]=(endt-begint)[3]
}

save.image("ADMMvsQP.RData")


c(mean(svradmm1$rmse),mean(ensvr1$rmse))
c(mean(svradmm1$mae),mean(ensvr1$mae))
c(mean(svradmm1$nonzeroerror),mean(ensvr1$nonzeroerror))
c(mean(svradmm1$time),mean(ensvr1$time))


c(mean(svradmm2$rmse),mean(ensvr2$rmse))
c(mean(svradmm2$mae),mean(ensvr2$mae))
c(mean(svradmm2$nonzeroerror),mean(ensvr2$nonzeroerror))
c(mean(svradmm2$time),mean(ensvr2$time))

c(mean(svradmm3$rmse),mean(ensvr3$rmse))
c(mean(svradmm3$mae),mean(ensvr3$mae))
c(mean(svradmm3$nonzeroerror),mean(ensvr3$nonzeroerror))
c(mean(svradmm3$time),mean(ensvr3$time))


c(mean(svradmm4$rmse),mean(ensvr4$rmse))
c(mean(svradmm4$mae),mean(ensvr4$mae))
c(mean(svradmm4$nonzeroerror),mean(ensvr4$nonzeroerror))
c(mean(svradmm4$time),mean(ensvr4$time))

c(mean(svradmm5$rmse),mean(ensvr5$rmse))
c(mean(svradmm5$mae),mean(ensvr5$mae))
c(mean(svradmm5$nonzeroerror),mean(ensvr5$nonzeroerror))
c(mean(svradmm5$time),mean(ensvr5$time))


c(mean(svradmm6$rmse),mean(ensvr6$rmse))
c(mean(svradmm6$mae),mean(ensvr6$mae))
c(mean(svradmm6$nonzeroerror),mean(ensvr6$nonzeroerror))
c(mean(svradmm6$time),mean(ensvr6$time))

c(mean(svradmm7$rmse),mean(ensvr7$rmse))
c(mean(svradmm7$mae),mean(ensvr7$mae))
c(mean(svradmm7$nonzeroerror),mean(ensvr7$nonzeroerror))
c(mean(svradmm7$time),mean(ensvr7$time))

c(mean(svradmm8$rmse),mean(ensvr8$rmse))
c(mean(svradmm8$mae),mean(ensvr8$mae))
c(mean(svradmm8$nonzeroerror),mean(ensvr8$nonzeroerror))
c(mean(svradmm8$time),mean(ensvr8$time))


c(mean(svradmm9$rmse),mean(ensvr9$rmse))
c(mean(svradmm9$mae),mean(ensvr9$mae))
c(mean(svradmm9$nonzeroerror),mean(ensvr9$nonzeroerror))
c(mean(svradmm9$time),mean(ensvr9$time))

c(mean(svradmm10$rmse),mean(ensvr10$rmse))
c(mean(svradmm10$mae),mean(ensvr10$mae))
c(mean(svradmm10$nonzeroerror),mean(ensvr10$nonzeroerror))
c(mean(svradmm10$time),mean(ensvr10$time))

c(mean(svradmm11$rmse),mean(ensvr11$rmse))
c(mean(svradmm11$mae),mean(ensvr11$mae))
c(mean(svradmm11$nonzeroerror),mean(ensvr11$nonzeroerror))
c(mean(svradmm11$time),mean(ensvr11$time))

c(mean(svradmm12$rmse),mean(ensvr12$rmse))
c(mean(svradmm12$mae),mean(ensvr12$mae))
c(mean(svradmm12$nonzeroerror),mean(ensvr12$nonzeroerror))
c(mean(svradmm12$time),mean(ensvr12$time))
