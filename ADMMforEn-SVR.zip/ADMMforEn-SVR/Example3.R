#Example3
n.train=500
p=2000
n.test=500
source("ADMMFunction.R")
################################# rho=0
rho=0
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(1)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr1=list()
ensvr1$rmse=rep(0,10)
ensvr1$mae=rep(0,10)
ensvr1$w=matrix(0,nrow=10,ncol=p)
ensvr1$nonzeroerror=rep(0,10)
ensvr1$sparse=rep(0,10)
ensvr1$k=rep(0,10)
ensvr1$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr1$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr1$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr1$w[i,]=result$w
  ensvr1$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr1$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr1$k[i]=result$k
  ensvr1$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}

################################# rho=0.1
rho=0.1
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(2)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr2=list()
ensvr2$rmse=rep(0,10)
ensvr2$mae=rep(0,10)
ensvr2$w=matrix(0,nrow=10,ncol=p)
ensvr2$nonzeroerror=rep(0,10)
ensvr2$sparse=rep(0,10)
ensvr2$k=rep(0,10)
ensvr2$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr2$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr2$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr2$w[i,]=result$w
  ensvr2$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr2$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr2$k[i]=result$k
  ensvr2$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}


################################# rho=0.2
rho=0.2
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(3)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr3=list()
ensvr3$rmse=rep(0,10)
ensvr3$mae=rep(0,10)
ensvr3$w=matrix(0,nrow=10,ncol=p)
ensvr3$nonzeroerror=rep(0,10)
ensvr3$sparse=rep(0,10)
ensvr3$k=rep(0,10)
ensvr3$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr3$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr3$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr3$w[i,]=result$w
  ensvr3$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr3$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr3$k[i]=result$k
  ensvr3$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}

################################# rho=0.3
rho=0.3
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(4)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr4=list()
ensvr4$rmse=rep(0,10)
ensvr4$mae=rep(0,10)
ensvr4$w=matrix(0,nrow=10,ncol=p)
ensvr4$nonzeroerror=rep(0,10)
ensvr4$sparse=rep(0,10)
ensvr4$k=rep(0,10)
ensvr4$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr4$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr4$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr4$w[i,]=result$w
  ensvr4$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr4$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr4$k[i]=result$k
  ensvr4$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}


################################# rho=0.4
rho=0.4
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(5)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr5=list()
ensvr5$rmse=rep(0,10)
ensvr5$mae=rep(0,10)
ensvr5$w=matrix(0,nrow=10,ncol=p)
ensvr5$nonzeroerror=rep(0,10)
ensvr5$sparse=rep(0,10)
ensvr5$k=rep(0,10)
ensvr5$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr5$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr5$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr5$w[i,]=result$w
  ensvr5$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr5$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr5$k[i]=result$k
  ensvr5$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}


################################# rho=0.5
rho=0.5
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(6)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr6=list()
ensvr6$rmse=rep(0,10)
ensvr6$mae=rep(0,10)
ensvr6$w=matrix(0,nrow=10,ncol=p)
ensvr6$nonzeroerror=rep(0,10)
ensvr6$sparse=rep(0,10)
ensvr6$k=rep(0,10)
ensvr6$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr6$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr6$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr6$w[i,]=result$w
  ensvr6$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr6$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr6$k[i]=result$k
  ensvr6$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}


################################# rho=0.6
rho=0.6
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(7)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr7=list()
ensvr7$rmse=rep(0,10)
ensvr7$mae=rep(0,10)
ensvr7$w=matrix(0,nrow=10,ncol=p)
ensvr7$nonzeroerror=rep(0,10)
ensvr7$sparse=rep(0,10)
ensvr7$k=rep(0,10)
ensvr7$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr7$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr7$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr7$w[i,]=result$w
  ensvr7$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr7$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr7$k[i]=result$k
  ensvr7$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}

################################# rho=0.7
rho=0.7
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(8)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr8=list()
ensvr8$rmse=rep(0,10)
ensvr8$mae=rep(0,10)
ensvr8$w=matrix(0,nrow=10,ncol=p)
ensvr8$nonzeroerror=rep(0,10)
ensvr8$sparse=rep(0,10)
ensvr8$k=rep(0,10)
ensvr8$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr8$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr8$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr8$w[i,]=result$w
  ensvr8$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr8$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr8$k[i]=result$k
  ensvr8$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}


################################# rho=0.8
rho=0.8
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(9)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr9=list()
ensvr9$rmse=rep(0,10)
ensvr9$mae=rep(0,10)
ensvr9$w=matrix(0,nrow=10,ncol=p)
ensvr9$nonzeroerror=rep(0,10)
ensvr9$sparse=rep(0,10)
ensvr9$k=rep(0,10)
ensvr9$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr9$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr9$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr9$w[i,]=result$w
  ensvr9$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr9$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr9$k[i]=result$k
  ensvr9$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}

################################# rho=0.9
rho=0.9
sigma=matrix(0,p,p)
for(i in 1:p){
  for(j in 1:p){
    sigma[i,j]=rho^abs(i-j)
  }
}
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(10)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)%*%t(chol(sigma))
  x.train.list[[i]][,1]=pnorm(x.train.list[[i]][,1])
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))+0.7*x.train.list[[i]][,1]*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)%*%t(chol(sigma))
  y.test.list[[i]]=x.test.list[[i]]%*%c(0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,rep(0,p-20))
}

lambda1=10
lambda2=0.001
epsilon=0.1
beta=5
eta=0.9
ensvr10=list()
ensvr10$rmse=rep(0,10)
ensvr10$mae=rep(0,10)
ensvr10$w=matrix(0,nrow=10,ncol=p)
ensvr10$nonzeroerror=rep(0,10)
ensvr10$sparse=rep(0,10)
ensvr10$k=rep(0,10)
ensvr10$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr10$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr10$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr10$w[i,]=result$w
  ensvr10$nonzeroerror[i]=mean(abs(result$w[c(6,12,15,20)]-c(1,1,1,1)))
  ensvr10$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr10$k[i]=result$k
  ensvr10$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}

save.image("Example3.RData")
