#Example4
n.train=500
p=2000
n.test=500
source("ADMMFunction.R")
cc=sqrt(3)*((t(c(4,3,2,-2,-2,-2,rep(0,p-6)))%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))[1,1])
#######################################
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(1)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)
  error=rnorm(n.train,0,1)
  y.train.list[[i]]=x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))+(1/cc)*(x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))^2*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)
  y.test.list[[i]]=x.test.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))
}

lambda1=10
lambda2=0.01
epsilon=0.1
beta=1
eta=0.9
ensvr1=list()
ensvr1$rmse=rep(0,10)
ensvr1$mae=rep(0,10)
ensvr1$w=matrix(0,nrow=10,ncol=p)
ensvr1$nonzeroerror=rep(0,10)
ensvr1$sparse=rep(0,10)
ensvr1$k=rep(0,10)
ensvr1$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr1$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr1$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr1$w[i,]=result$w
  ensvr1$nonzeroerror[i]=mean(abs(result$w[1:6]-c(4,3,2,-2,-2,-2)))
  ensvr1$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr1$k[i]=result$k
  ensvr1$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}



#######################################
x.train.list=list()
y.train.list=list()
x.test.list=list()
y.test.list=list()
set.seed(2)
for(i in 1:10){
  x.train.list[[i]]=matrix(rnorm(n.train*p),n.train,p)
  error=rlnorm(n.train)
  y.train.list[[i]]=x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))+(1/cc)*(x.train.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6)))^2*error
  x.test.list[[i]]=matrix(rnorm(n.test*p),n.test,p)
  y.test.list[[i]]=x.test.list[[i]]%*%c(4,3,2,-2,-2,-2,rep(0,p-6))
}

lambda1=10
lambda2=0.01
epsilon=0.1
beta=1
eta=0.9
ensvr2=list()
ensvr2$rmse=rep(0,10)
ensvr2$mae=rep(0,10)
ensvr2$w=matrix(0,nrow=10,ncol=p)
ensvr2$nonzeroerror=rep(0,10)
ensvr2$sparse=rep(0,10)
ensvr2$k=rep(0,10)
ensvr2$time=rep(0,10)
for(i in 1:10){
  result=ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test.list[[i]]%*%result$w+result$b
  ensvr2$rmse[i]=sqrt(mean((yhat-y.test.list[[i]])^2))
  ensvr2$mae[i]=mean(abs(yhat-y.test.list[[i]]))
  ensvr2$w[i,]=result$w
  ensvr2$nonzeroerror[i]=mean(abs(result$w[1:6]-c(4,3,2,-2,-2,-2)))
  ensvr2$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr2$k[i]=result$k
  ensvr2$time[i]=system.time(ADMM1(x.train.list[[i]],y.train.list[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}

save.image("Example4.RData")

