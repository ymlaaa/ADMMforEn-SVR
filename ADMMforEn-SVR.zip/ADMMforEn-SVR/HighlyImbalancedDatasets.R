source("ADMMFunctionForHighlyImbalancedDataset.R")

############Real2
data=read.table("colon-cancer.txt",header=TRUE)
y=data[,1]
x=data[,-1]
x=as.matrix(x)

index=sort(c(sample(which(y==-1),30),sample(which(y==1),5)))
y.train=y[index]
x.train=x[index,]
y.test=y[-index]
x.test=x[-index,]

#En-SVR
lambda1=0.1
lambda2=0.01
epsilon=0.1
beta=10
eta=0.9
real2.ensvr=list()
real2.ensvr$trainright=0
real2.ensvr$testright=0
real2.ensvr$sparse=0
real2.ensvr$ite=0
real2.ensvr$time=0
begint=proc.time()
result=ADMM1(x.train,y.train,lambda1,lambda2,epsilon,beta,eta)
endt=proc.time()
yhat.train=x.train%*%result$w+result$b
yhat.test=x.test%*%result$w+result$b
y.train.class=ifelse(yhat.train>0,1,-1)
y.test.class=ifelse(yhat.test>0,1,-1)
real2.ensvr$trainright=sum(diag(table(y.train,y.train.class)))/length(y.train)
real2.ensvr$testright=sum(diag(table(y.test,y.test.class)))/length(y.test)
real2.ensvr$sparse=sum(abs(result$w)<10^(-2))
real2.ensvr$ite=result$k
real2.ensvr$time=(endt-begint)[3]


############Real4
data=read.table("duke.txt",header=TRUE)
y=data[,1]
x=data[,-1]
x=as.matrix(x)

index=sort(c(sample(which(y==-1),5),sample(which(y==1),20)))
y.train=y[index]
x.train=x[index,]
y.test=y[-index]
x.test=x[-index,]

#En-SVR
lambda1=0.01
lambda2=0.001
epsilon=0.1
beta=1
eta=0.9
real4.ensvr=list()
real4.ensvr$trainright=0
real4.ensvr$testright=0
real4.ensvr$sparse=0
real4.ensvr$ite=0
real4.ensvr$time=0
begint=proc.time()
result=ADMM1(x.train,y.train,lambda1,lambda2,epsilon,beta,eta)
endt=proc.time()
yhat.train=x.train%*%result$w+result$b
yhat.test=x.test%*%result$w+result$b
y.train.class=ifelse(yhat.train>0,1,-1)
y.test.class=ifelse(yhat.test>0,1,-1)
real4.ensvr$trainright=sum(diag(table(y.train,y.train.class)))/length(y.train)
real4.ensvr$testright=sum(diag(table(y.test,y.test.class)))/length(y.test)
real4.ensvr$sparse=sum(abs(result$w)<10^(-2))
real4.ensvr$ite=result$k
real4.ensvr$time=(endt-begint)[3]


############Real5
data=read.table("GSE755_series_matrix.txt",header=F)
x=t(data[,-1])
colnames(x)=data[,1]
y=c(rep(1,36),rep(-1,137))
x=scale(x)

index=sort(c(sample(which(y==-1),100),sample(which(y==1),20)))
y.train=y[index]
x.train=x[index,]
y.test=y[-index]
x.test=x[-index,]

#En-SVR
lambda1=0.01
lambda2=0.01
epsilon=0.1
beta=1
eta=0.9
real5.ensvr=list()
real5.ensvr$trainright=0
real5.ensvr$testright=0
real5.ensvr$sparse=0
real5.ensvr$ite=0
real5.ensvr$time=0
begint=proc.time()
result=ADMM1(x.train,y.train,lambda1,lambda2,epsilon,beta,eta)
endt=proc.time()
yhat.train=x.train%*%result$w+result$b
yhat.test=x.test%*%result$w+result$b
y.train.class=ifelse(yhat.train>0,1,-1)
y.test.class=ifelse(yhat.test>0,1,-1)
real5.ensvr$trainright=sum(diag(table(y.train,y.train.class)))/length(y.train)
real5.ensvr$testright=sum(diag(table(y.test,y.test.class)))/length(y.test)
real5.ensvr$sparse=sum(abs(result$w)<10^(-2))
real5.ensvr$ite=result$k
real5.ensvr$time=(endt-begint)[3]


############Real6
data=read.table("prostate.txt",header=T)
y=data[,1]
x=data[,-1]
x=as.matrix(x)
x=scale(x)

index=sort(c(sample(which(y==-1),45),sample(which(y==1),15)))
y.train=y[index]
x.train=x[index,]
y.test=y[-index]
x.test=x[-index,]

#En-SVR
lambda1=0.01
lambda2=0.01
epsilon=0.1
beta=1
eta=0.9
real6.ensvr=list()
real6.ensvr$trainright=0
real6.ensvr$testright=0
real6.ensvr$sparse=0
real6.ensvr$ite=0
real6.ensvr$time=0
begint=proc.time()
result=ADMM1(x.train,y.train,lambda1,lambda2,epsilon,beta,eta)
endt=proc.time()
yhat.train=x.train%*%result$w+result$b
yhat.test=x.test%*%result$w+result$b
y.train.class=ifelse(yhat.train>0,1,-1)
y.test.class=ifelse(yhat.test>0,1,-1)
real6.ensvr$trainright=sum(diag(table(y.train,y.train.class)))/length(y.train)
real6.ensvr$testright=sum(diag(table(y.test,y.test.class)))/length(y.test)
real6.ensvr$sparse=sum(abs(result$w)<10^(-2))
real6.ensvr$ite=result$k
real6.ensvr$time=(endt-begint)[3]


############Real7
data=read.table("DLBCL.txt",header=T)
y=data[,1]
x=data[,-1]
x=as.matrix(x)
x=scale(x)

index=sort(c(sample(which(y==-1),10),sample(which(y==1),50)))
y.train=y[index]
x.train=x[index,]
y.test=y[-index]
x.test=x[-index,]

#En-SVR
lambda1=0.01
lambda2=0.01
epsilon=0.1
beta=1
eta=0.9
real7.ensvr=list()
real7.ensvr$trainright=0
real7.ensvr$testright=0
real7.ensvr$sparse=0
real7.ensvr$ite=0
real7.ensvr$time=0
begint=proc.time()
result=ADMM1(x.train,y.train,lambda1,lambda2,epsilon,beta,eta)
endt=proc.time()
yhat.train=x.train%*%result$w+result$b
yhat.test=x.test%*%result$w+result$b
y.train.class=ifelse(yhat.train>0,1,-1)
y.test.class=ifelse(yhat.test>0,1,-1)
real7.ensvr$trainright=sum(diag(table(y.train,y.train.class)))/length(y.train)
real7.ensvr$testright=sum(diag(table(y.test,y.test.class)))/length(y.test)
real7.ensvr$sparse=sum(abs(result$w)<10^(-2))
real7.ensvr$ite=result$k
real7.ensvr$time=(endt-begint)[3]


save.image("HighlyImbalancedDatasets.RData")


real2.ensvr$trainright
real2.ensvr$testright
real2.ensvr$sparse
real2.ensvr$ite
real2.ensvr$time

real4.ensvr$trainright
real4.ensvr$testright
real4.ensvr$sparse
real4.ensvr$ite
real4.ensvr$time

real5.ensvr$trainright
real5.ensvr$testright
real5.ensvr$sparse
real5.ensvr$ite
real5.ensvr$time


real6.ensvr$trainright
real6.ensvr$testright
real6.ensvr$sparse
real6.ensvr$ite
real6.ensvr$time


real7.ensvr$trainright
real7.ensvr$testright
real7.ensvr$sparse
real7.ensvr$ite
real7.ensvr$time

