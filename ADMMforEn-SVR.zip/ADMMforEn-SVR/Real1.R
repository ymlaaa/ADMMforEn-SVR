########################################################## data processing
data=read.table("GSE5680_series_matrix.txt",header=F)
data_new=t(data[,-1])
colnames(data_new)=data[,1]
col_maxvalue=apply(data_new,2,max)
col_minvalue=apply(data_new,2,min)
alldata.quan25=quantile(matrix(data_new,nrow=1),0.25)
index=(col_maxvalue>alldata.quan25) & (2^col_maxvalue/2^col_minvalue > 2)
sum(index)  # 18986 
index=(round(col_maxvalue,3)>round(alldata.quan25,3)) & (2^round(col_maxvalue,3)/2^round(col_minvalue,3) > 2)
sum(index)  # 18976 
data_shaixuan=data_new[,index]
dim(data_shaixuan)  # 120 18976
"1389163_at" %in% colnames(data_shaixuan)  # TRUE
which(colnames(data_shaixuan)=="1389163_at") # 13037
data_shaixuan_new=data.frame(data_shaixuan[,13037],data_shaixuan[,-13037])
colnames(data_shaixuan_new)=c("1389163_at",colnames(data_shaixuan)[-13037])
which(colnames(data_shaixuan_new)=="1389163_at") # 1
dim(data_shaixuan_new)
y=data_shaixuan_new[,1] # 120 * 1
x=data_shaixuan_new[,-1]  # 120 * 18975
source("ADMMFunction.R")
################################################################### data selecting
y=data_shaixuan_new[,1] # 120 * 1
x=data_shaixuan_new[,-1]  # 120 * 18975
x=as.matrix(x)
colunif=function(X){
  Y=X
  if(is.vector(Y)){return((Y-min(Y))/(max(Y)-min(Y)))}
  for (i in 1:dim(X)[2]) {
    Y[,i]<-(X[,i]-min(X[,i]))/(max(X[,i]-min(X[,i])))
  }
  return(Y)
}
y_colunif=colunif(y)
x_colunif=colunif(x)
order(apply(x_colunif,2,var),decreasing=TRUE)
x_select_3000=x[,order(apply(x_colunif,2,var),decreasing=TRUE)[1:3000]]
###################################################################### data fitting
############################# all data 
lambda1=0.001
lambda2=0.01
epsilon=0.1
beta=1
eta=0.9
ensvr1=list()
ensvr1$rmse=0
ensvr1$mae=0
ensvr1$sparse=0
ensvr1$k=0
ensvr1$time=0
result=ADMM1(x_select_3000,y,lambda1,lambda2,epsilon,beta,eta)
yhat=x_select_3000%*%result$w+result$b
ensvr1$rmse=sqrt(mean((y-yhat)^2))
ensvr1$mae=mean(abs(y-yhat))
ensvr1$sparse=sum(abs(result$w)<10^(-2))
ensvr1$k=result$k
ensvr1$time=system.time(ADMM1(x_select_3000,y,lambda1,lambda2,epsilon,beta,eta))[3]

#############################data partition
randompartition=list()
x.train=list()
y.train=list()
x.test=list()
y.test=list()
set.seed(1)
for(i in 1:50){
  randompartition[[i]]=sort(sample(1:120,80))
  x.train[[i]]=x_select_3000[randompartition[[i]],]
  y.train[[i]]=y[randompartition[[i]]]
  x.test[[i]]=x_select_3000[-randompartition[[i]],]
  y.test[[i]]=y[-randompartition[[i]]]
}

lambda1=0.001
lambda2=0.001
epsilon=0.1
beta=1
eta=0.9
ensvr2=list()
ensvr2$rmse=rep(0,50)
ensvr2$mae=rep(0,50)
ensvr2$sparse=rep(0,50)
ensvr2$k=rep(0,50)
ensvr2$time=rep(0,50)
for(i in 1:50){
  result=ADMM1(x.train[[i]],y.train[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test[[i]]%*%result$w+result$b
  ensvr2$rmse[i]=sqrt(mean((yhat-y.test[[i]])^2))
  ensvr2$mae[i]=mean(abs(yhat-y.test[[i]]))
  ensvr2$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr2$k[i]=result$k
  ensvr2$time[i]=system.time(ADMM1(x.train[[i]],y.train[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}

save.image("Real1.RData")
