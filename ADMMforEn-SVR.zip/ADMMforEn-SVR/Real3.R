########################################### data processing
data=read.table("leu.txt",header=TRUE)
y=data[,1]
x=data[,-1]
x=as.matrix(x)
data_test=read.table("leu.t.txt",header=TRUE)
y_test=data_test[,1]
x_test=data_test[,-1]
x_test=as.matrix(x_test)
source("ADMMFunction.R")
######################################### data fitting
lambda1=0.1
lambda2=0.01
epsilon=0.1
beta=10
eta=0.9
ensvr1=list()
ensvr1$right.train=0
ensvr1$right.test=0
ensvr1$sparse=0
ensvr1$k=0
ensvr1$time=0
result=ADMM1(x,y,lambda1,lambda2,epsilon,beta,eta)
yhat=x%*%result$w+result$b
yhat_test=x_test%*%result$w+result$b
y.class=ifelse(yhat>0,1,-1)
y_test.class=ifelse(yhat_test>0,1,-1)
ensvr1$right.train=sum(diag(table(y,y.class)))/length(y)
ensvr1$right.test=sum(diag(table(y_test,y_test.class)))/length(y_test)
ensvr1$sparse=sum(abs(result$w)<10^(-2))
ensvr1$k=result$k
ensvr1$time=system.time(ADMM1(x,y,lambda1,lambda2,epsilon,beta,eta))[3]

save.image("Real3.RData")
