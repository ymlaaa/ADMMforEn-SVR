############################################### data processing
data=read.table("GSE755_series_matrix.txt",header=F)
x=t(data[,-1])
colnames(x)=data[,1]
y=c(rep(1,36),rep(-1,137))
x=scale(x)
source("ADMMFunction.R")
############################################### data fitting
################## all data
#EnSVR
lambda1=0.01
lambda2=0.01
epsilon=0.1
beta=1
eta=0.9
ensvr1=list()
ensvr1$right=0
ensvr1$sparse=0
ensvr1$k=0
ensvr1$time=0
result=ADMM1(x,y,lambda1,lambda2,epsilon,beta,eta)
yhat=x%*%result$w+result$b
y.class=ifelse(yhat>0,1,-1)
ensvr1$right=sum(diag(table(y,y.class)))/length(y)
ensvr1$sparse=sum(abs(result$w)<10^(-2))
ensvr1$k=result$k
ensvr1$time=system.time(ADMM1(x,y,lambda1,lambda2,epsilon,beta,eta))[3]

##################data partition
randompartition=list()
x.train=list()
y.train=list()
x.test=list()
y.test=list()
set.seed(1)
for(i in 1:50){
  randompartition[[i]]=sort(sample(1:173,140))
  x.train[[i]]=x[randompartition[[i]],]
  y.train[[i]]=y[randompartition[[i]]]
  x.test[[i]]=x[-randompartition[[i]],]
  y.test[[i]]=y[-randompartition[[i]]]
}
#EnSVR
lambda1=0.001
lambda2=0.01
epsilon=0.1
beta=0.1
eta=0.9
ensvr2=list()
ensvr2$right=rep(0,50)
ensvr2$sparse=rep(0,50)
ensvr2$k=rep(0,50)
ensvr2$time=rep(0,50)
for(i in 1:50){
  result=ADMM1(x.train[[i]],y.train[[i]],lambda1,lambda2,epsilon,beta,eta)
  yhat=x.test[[i]]%*%result$w+result$b
  y.class=ifelse(yhat>0,1,-1)
  ensvr2$right[i]=sum(diag(table(y.test[[i]],y.class)))/length(y.test[[i]])
  ensvr2$sparse[i]=sum(abs(result$w)<10^(-2))
  ensvr2$k[i]=result$k
  ensvr2$time[i]=system.time(ADMM1(x.train[[i]],y.train[[i]],lambda1,lambda2,epsilon,beta,eta))[3]
}

save.image("Real5.RData")



