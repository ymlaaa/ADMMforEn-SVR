#Example1~6
###rho=0
mean(ensvr1$rmse)
mean(ensvr1$sparse)
mean(ensvr1$nonzeroerror)
mean(ensvr1$k)
mean(ensvr1$time)

###rho=0.1
mean(ensvr2$rmse)
mean(ensvr2$sparse)
mean(ensvr2$nonzeroerror)
mean(ensvr2$k)
mean(ensvr2$time)


###rho=0.2
mean(ensvr3$rmse)
mean(ensvr3$sparse)
mean(ensvr3$nonzeroerror)
mean(ensvr3$k)
mean(ensvr3$time)


###rho=0.3
mean(ensvr4$rmse)
mean(ensvr4$sparse)
mean(ensvr4$nonzeroerror)
mean(ensvr4$k)
mean(ensvr4$time)


###rho=0.4
mean(ensvr5$rmse)
mean(ensvr5$sparse)
mean(ensvr5$nonzeroerror)
mean(ensvr5$k)
mean(ensvr5$time)

###rho=0.5
mean(ensvr6$rmse)
mean(ensvr6$sparse)
mean(ensvr6$nonzeroerror)
mean(ensvr6$k)
mean(ensvr6$time)


###rho=0.6
mean(ensvr7$rmse)
mean(ensvr7$sparse)
mean(ensvr7$nonzeroerror)
mean(ensvr7$k)
mean(ensvr7$time)


###rho=0.7
mean(ensvr8$rmse)
mean(ensvr8$sparse)
mean(ensvr8$nonzeroerror)
mean(ensvr8$k)
mean(ensvr8$time)


###rho=0.8
mean(ensvr9$rmse)
mean(ensvr9$sparse)
mean(ensvr9$nonzeroerror)
mean(ensvr9$k)
mean(ensvr9$time)

###rho=0.9
mean(ensvr10$rmse)
mean(ensvr10$sparse)
mean(ensvr10$nonzeroerror)
mean(ensvr10$k)
mean(ensvr10$time)


#Real1
ensvr1$rmse
ensvr1$mae
ensvr1$sparse # p(dimensional) - ensvr1$sparse  is the number of significant coefficients.
ensvr1$k
ensvr1$time


mean(ensvr2$rmse)
mean(ensvr2$mae)
mean(ensvr2$sparse) # p(dimensional) - ensvr1$sparse  is the number of significant coefficients.
mean(ensvr2$k)
mean(ensvr2$time)

#Real2
ensvr1$right
ensvr1$sparse # p(dimensional) - ensvr1$sparse  is the number of significant coefficients.
ensvr1$k
ensvr1$time


mean(ensvr2$right)
mean(ensvr2$sparse) # p(dimensional) - ensvr1$sparse  is the number of significant coefficients.
mean(ensvr2$k)
mean(ensvr2$time)


#Real3
ensvr1$right.train
ensvr1$right.test
ensvr1$sparse # p(dimensional) - ensvr1$sparse  is the number of significant coefficients.
ensvr1$k
ensvr1$time

